using Microsoft.EntityFrameworkCore;
using razordb.Data;
using razordb.Models;

namespace razordb.Services
{
    public interface IActividadService
    {
        Task<IEnumerable<Tarea>> ObtenerTodasLasActividadesAsync();
        Task<Tarea?> ObtenerActividadPorIdAsync(int id);
        Task<Tarea> CrearActividadAsync(Tarea actividad);
        Task<bool> ActualizarActividadAsync(Tarea actividad);
        Task<bool> EliminarActividadAsync(int id);
        Task<IEnumerable<Tarea>> FiltrarActividadesPorEstadoAsync(string estado);
        Task<IEnumerable<Tarea>> ObtenerActividadesPorUsuarioAsync(int usuarioId);
        Task<bool> CambiarEstadoActividadAsync(int id, string nuevoEstado);
        EstadisticasActividades ObtenerEstadisticas(IEnumerable<Tarea> actividades);
    }

    public class ActividadService : IActividadService
    {
        private readonly TareaDbContext _contexto;

        public ActividadService(TareaDbContext contexto)
        {
            _contexto = contexto;
        }

        public async Task<IEnumerable<Tarea>> ObtenerTodasLasActividadesAsync()
        {
            return await _contexto.Tareas
                .OrderBy(t => t.fechaVencimiento)
                .ToListAsync();
        }

        public async Task<Tarea?> ObtenerActividadPorIdAsync(int id)
        {
            return await _contexto.Tareas
                .FirstOrDefaultAsync(t => t.Id == id);
        }

        public async Task<Tarea> CrearActividadAsync(Tarea actividad)
        {
            _contexto.Tareas.Add(actividad);
            await _contexto.SaveChangesAsync();
            return actividad;
        }

        public async Task<bool> ActualizarActividadAsync(Tarea actividad)
        {
            try
            {
                _contexto.Entry(actividad).State = EntityState.Modified;
                await _contexto.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateConcurrencyException)
            {
                var existe = await _contexto.Tareas.AnyAsync(t => t.Id == actividad.Id);
                if (!existe)
                {
                    return false;
                }
                throw;
            }
        }

        public async Task<bool> EliminarActividadAsync(int id)
        {
            var actividad = await _contexto.Tareas.FindAsync(id);
            if (actividad == null)
            {
                return false;
            }

            _contexto.Tareas.Remove(actividad);
            await _contexto.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<Tarea>> FiltrarActividadesPorEstadoAsync(string estado)
        {
            return await _contexto.Tareas
                .Where(t => t.estado == estado)
                .OrderBy(t => t.fechaVencimiento)
                .ToListAsync();
        }

        public async Task<IEnumerable<Tarea>> ObtenerActividadesPorUsuarioAsync(int usuarioId)
        {
            return await _contexto.Tareas
                .Where(t => t.idUsuario == usuarioId)
                .OrderBy(t => t.fechaVencimiento)
                .ToListAsync();
        }

        public async Task<bool> CambiarEstadoActividadAsync(int id, string nuevoEstado)
        {
            var actividad = await _contexto.Tareas.FindAsync(id);
            if (actividad == null)
            {
                return false;
            }

            actividad.estado = nuevoEstado;
            await _contexto.SaveChangesAsync();
            return true;
        }

        public EstadisticasActividades ObtenerEstadisticas(IEnumerable<Tarea> actividades)
        {
            return new EstadisticasActividades
            {
                TotalActividades = actividades.Count(),
                ActividadesPendientes = actividades.Count(a => a.estado == "Pendiente"),
                ActividadesEnCurso = actividades.Count(a => a.estado == "En Curso"),
                ActividadesCompletadas = actividades.Count(a => a.estado == "Finalizado"),
                ActividadesVencidas = actividades.Count(a => a.EstaVencida()),
                PorcentajeCompletado = actividades.Any() ? 
                    Math.Round((double)actividades.Count(a => a.estado == "Finalizado") / actividades.Count() * 100, 1) : 0
            };
        }
    }

    public class EstadisticasActividades
    {
        public int TotalActividades { get; set; }
        public int ActividadesPendientes { get; set; }
        public int ActividadesEnCurso { get; set; }
        public int ActividadesCompletadas { get; set; }
        public int ActividadesVencidas { get; set; }
        public double PorcentajeCompletado { get; set; }
    }
}