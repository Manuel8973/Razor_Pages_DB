﻿using Bogus;
using razordb.Data;
using razordb.Models;
using Microsoft.EntityFrameworkCore;

namespace razordb.Seeders
{
    public static class TareaSeeder
    {
        public static void SeedData(TareaDbContext context)
        {
            context.Database.EnsureCreated();

            if (context.Tareas.Any())
            {
                return;
            }

            var actividadesFaker = new Faker<Tarea>("es")
                .RuleFor(a => a.nombreTarea, f => GenerarNombreActividad(f))
                .RuleFor(a => a.fechaVencimiento, f => GenerarFechaVencimiento(f))
                .RuleFor(a => a.estado, f => f.PickRandom(new[] { "Pendiente", "En Curso", "Finalizado" }))
                .RuleFor(a => a.idUsuario, f => f.Random.Number(1, 5));

            var actividades = actividadesFaker.Generate(30);

            actividades.AddRange(new List<Tarea>
            {
                new Tarea 
                { 
                    nombreTarea = "Implementar sistema de notificaciones push",
                    fechaVencimiento = DateTime.Now.AddDays(5),
                    estado = "En Curso",
                    idUsuario = 1
                },
                new Tarea 
                { 
                    nombreTarea = "Optimizar rendimiento de la base de datos",
                    fechaVencimiento = DateTime.Now.AddDays(10),
                    estado = "Pendiente",
                    idUsuario = 2
                },
                new Tarea 
                { 
                    nombreTarea = "Actualizar documentación del API",
                    fechaVencimiento = DateTime.Now.AddDays(-2),
                    estado = "Finalizado",
                    idUsuario = 3
                },
                new Tarea 
                { 
                    nombreTarea = "Configurar entorno de pruebas automatizadas",
                    fechaVencimiento = DateTime.Now.AddDays(15),
                    estado = "Pendiente",
                    idUsuario = 4
                },
                new Tarea 
                { 
                    nombreTarea = "Diseñar interfaz para panel administrativo",
                    fechaVencimiento = DateTime.Now.AddDays(8),
                    estado = "En Curso",
                    idUsuario = 5
                }
            });

            context.Tareas.AddRange(actividades);
            context.SaveChanges();

            Console.WriteLine($"✅ Sistema TaskFlow Pro inicializado con {actividades.Count} actividades de demostración.");
        }

        private static string GenerarNombreActividad(Faker faker)
        {
            var tiposActividad = new[]
            {
                "Desarrollar módulo de {0}",
                "Revisar código de {0}",
                "Implementar funcionalidad de {0}",
                "Optimizar proceso de {0}",
                "Configurar sistema de {0}",
                "Analizar requisitos para {0}",
                "Crear documentación de {0}",
                "Probar funcionalidad de {0}",
                "Migrar datos de {0}",
                "Actualizar configuración de {0}"
            };

            var conceptos = new[]
            {
                "autenticación", "reportes", "notificaciones", "búsqueda",
                "dashboard", "seguridad", "API REST", "cache",
                "logging", "backup", "monitoreo", "validaciones",
                "integración", "deployment", "testing", "documentación"
            };

            var plantilla = faker.PickRandom(tiposActividad);
            var concepto = faker.PickRandom(conceptos);
            
            return string.Format(plantilla, concepto);
        }

        private static DateTime GenerarFechaVencimiento(Faker faker)
        {
            var opcionTempo = faker.Random.Number(1, 10);
            
            if (opcionTempo <= 2)
            {
                return faker.Date.Past(0, DateTime.Now.AddDays(-1));
            }
            else if (opcionTempo <= 4)
            {
                return faker.Date.Between(DateTime.Now, DateTime.Now.AddDays(2));
            }
            else if (opcionTempo <= 7)
            {
                return faker.Date.Between(DateTime.Now.AddDays(2), DateTime.Now.AddDays(7));
            }
            else
            {
                return faker.Date.Between(DateTime.Now.AddDays(7), DateTime.Now.AddDays(30));
            }
        }
    }
}