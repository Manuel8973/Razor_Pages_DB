﻿using System;
using System.ComponentModel.DataAnnotations;

namespace razordb.Models
{
    public class Tarea
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El título de la actividad es obligatorio")]
        [MinLength(3, ErrorMessage = "El título debe contener al menos 3 caracteres")]
        [Display(Name = "Título de la Actividad")]
        public string nombreTarea { get; set; } = string.Empty;

        [Required(ErrorMessage = "La fecha límite es obligatoria")]
        [DataType(DataType.DateTime)]
        
        [Display(Name = "Fecha Límite")]
        public DateTime fechaVencimiento { get; set; }

        [Required(ErrorMessage = "El estado de progreso es obligatorio")]
        [Display(Name = "Estado de Progreso")]
        public string estado { get; set; } = "Pendiente";

        [Required(ErrorMessage = "El responsable asignado es obligatorio")]
        [Range(1, 5, ErrorMessage = "Debe seleccionar un responsable válido")]
        [Display(Name = "Responsable Asignado")]
        public int idUsuario { get; set; }

        public string ObtenerPrioridad()
        {
            var diasHastaVencimiento = (fechaVencimiento - DateTime.Now).Days;
            
            if (diasHastaVencimiento <= 1) return "Alta";
            if (diasHastaVencimiento <= 7) return "Media";
            return "Baja";
        }

        public int ObtenerProgresoEstimado()
        {
            return estado switch
            {
                "Finalizado" => 100,
                "En Curso" => 50,
                "Pendiente" => 0,
                _ => 0
            };
        }

        public bool EstaVencida()
        {
            return DateTime.Now > fechaVencimiento && estado != "Finalizado";
        }

        public string ObtenerDescripcionEstado()
        {
            return estado switch
            {
                "Pendiente" => "La actividad está en espera de ser iniciada",
                "En Curso" => "La actividad está siendo ejecutada actualmente",
                "Finalizado" => "La actividad ha sido completada exitosamente",
                _ => "Estado no definido"
            };
        }
    }
}