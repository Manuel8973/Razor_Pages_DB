﻿$(document).ready(function () {
    initializeGlobalFeatures();
    initializeAnimations();
    initializeNotifications();
});

function initializeGlobalFeatures() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    $('.alert').each(function() {
        var alert = $(this);
        if (!alert.hasClass('alert-permanent')) {
            setTimeout(function() {
                alert.fadeOut(500);
            }, 5000);
        }
    });

    $('.btn-danger, .btn-outline-danger').on('click', function(e) {
        if ($(this).data('skip-confirm')) return true;
        
        var action = $(this).text().trim();
        if (!confirm(`¿Está seguro de que desea ${action.toLowerCase()}?`)) {
            e.preventDefault();
            return false;
        }
    });
}

function initializeAnimations() {
    $('.fade-in-up').each(function(index) {
        $(this).css('animation-delay', (index * 0.1) + 's');
    });

    $('.card').hover(
        function() { 
            $(this).addClass('shadow-lg').css('transform', 'translateY(-2px)'); 
        },
        function() { 
            $(this).removeClass('shadow-lg').css('transform', 'translateY(0)'); 
        }
    );

    $('.btn').on('click', function() {
        $(this).addClass('btn-pulse');
        setTimeout(() => {
            $(this).removeClass('btn-pulse');
        }, 200);
    });

    $('.badge').hover(
        function() { $(this).addClass('badge-hover'); },
        function() { $(this).removeClass('badge-hover'); }
    );
}

function initializeNotifications() {
    if (!$('#notification-container').length) {
        $('body').append('<div id="notification-container" class="position-fixed top-0 end-0 p-3" style="z-index: 9999;"></div>');
    }
}

function showNotification(message, type = 'info', duration = 3000) {
    var iconClass = {
        'success': 'fas fa-check-circle',
        'error': 'fas fa-exclamation-triangle',
        'warning': 'fas fa-exclamation-circle',
        'info': 'fas fa-info-circle'
    };

    var bgClass = {
        'success': 'bg-success',
        'error': 'bg-danger',
        'warning': 'bg-warning',
        'info': 'bg-primary'
    };

    var notificationId = 'notification-' + Date.now();
    var notification = `
        <div id="${notificationId}" class="toast align-items-center text-white ${bgClass[type]} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="${iconClass[type]} me-2"></i>${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;

    $('#notification-container').append(notification);
    var toastElement = document.getElementById(notificationId);
    var toast = new bootstrap.Toast(toastElement, { delay: duration });
    toast.show();

    setTimeout(() => {
        $('#' + notificationId).remove();
    }, duration + 500);
}

function formatearFecha(fecha) {
    var opciones = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return new Date(fecha).toLocaleDateString('es-ES', opciones);
}

function calcularDiasRestantes(fechaVencimiento) {
    var hoy = new Date();
    var vencimiento = new Date(fechaVencimiento);
    var diferencia = vencimiento - hoy;
    return Math.ceil(diferencia / (1000 * 60 * 60 * 24));
}

function obtenerEstadoColor(estado) {
    var colores = {
        'Pendiente': { bg: 'bg-warning', text: 'text-dark', icon: 'fas fa-hourglass-half' },
        'En Curso': { bg: 'bg-primary', text: 'text-white', icon: 'fas fa-play' },
        'Finalizado': { bg: 'bg-success', text: 'text-white', icon: 'fas fa-check-circle' }
    };
    return colores[estado] || { bg: 'bg-secondary', text: 'text-white', icon: 'fas fa-question' };
}

function validarFormularioActividad(formulario) {
    var errores = [];
    var esValido = true;

    var nombre = $(formulario).find('[name="Tarea.nombreTarea"]').val().trim();
    if (nombre.length < 3) {
        errores.push('El nombre debe tener al menos 3 caracteres');
        esValido = false;
    }

    var fecha = new Date($(formulario).find('[name="Tarea.fechaVencimiento"]').val());
    var hoy = new Date();
    if (fecha <= hoy) {
        errores.push('La fecha debe ser posterior a la fecha actual');
        esValido = false;
    }

    var estado = $(formulario).find('[name="Tarea.estado"]').val();
    if (!estado) {
        errores.push('Debe seleccionar un estado');
        esValido = false;
    }

    var usuario = $(formulario).find('[name="Tarea.idUsuario"]').val();
    if (!usuario || usuario < 1 || usuario > 5) {
        errores.push('Debe seleccionar un usuario válido');
        esValido = false;
    }

    if (!esValido) {
        showNotification('Errores encontrados: ' + errores.join(', '), 'error', 5000);
    }

    return esValido;
}

function aplicarFiltrosAvanzados() {
    if (!$('#tablaActividades').length) return;

    var estadoFiltro = $('#filtroEstado').val();
    var usuarioFiltro = $('#filtroUsuario').val();
    var textoBusqueda = $('#busquedaTexto').val().toLowerCase();

    var filasVisibles = 0;

    $('#tablaActividades tbody tr').each(function() {
        var fila = $(this);
        var estado = fila.data('estado');
        var usuario = fila.data('usuario')?.toString();
        var nombre = fila.data('nombre')?.toLowerCase() || '';

        var mostrar = true;

        if (estadoFiltro && estado !== estadoFiltro) {
            mostrar = false;
        }

        if (usuarioFiltro && usuario !== usuarioFiltro) {
            mostrar = false;
        }

        if (textoBusqueda && nombre.indexOf(textoBusqueda) === -1) {
            mostrar = false;
        }

        if (mostrar) {
            fila.fadeIn(300);
            filasVisibles++;
        } else {
            fila.fadeOut(300);
        }
    });

    if (filasVisibles === 0) {
        if (!$('#no-results-message').length) {
            $('#tablaActividades tbody').append(`
                <tr id="no-results-message">
                    <td colspan="5" class="text-center py-4 text-muted">
                        <i class="fas fa-search fa-2x mb-2"></i>
                        <div>No se encontraron actividades con los filtros aplicados</div>
                    </td>
                </tr>
            `);
        }
    } else {
        $('#no-results-message').remove();
    }
}

function actualizarBarraProgreso(elemento, valor) {
    var barra = $(elemento);
    var color = valor == 100 ? 'bg-success' : 
               valor >= 50 ? 'bg-primary' : 'bg-warning';
    
    barra.css('width', valor + '%')
        .attr('class', 'progress-bar progress-bar-striped progress-bar-animated ' + color)
        .find('span').text(valor + '%');
    
    barra.css('transition', 'width 0.6s ease');
}

$(document).on('input change', '#filtroEstado, #filtroUsuario, #busquedaTexto', function() {
    aplicarFiltrosAvanzados();
});

$(document).on('focus', '.form-control, .form-select', function() {
    $(this).parent().find('.input-group-text').addClass('text-primary');
}).on('blur', '.form-control, .form-select', function() {
    $(this).parent().find('.input-group-text').removeClass('text-primary');
});

$(document).on('submit', 'form', function(e) {
    if ($(this).hasClass('skip-validation')) return true;
    
    if ($(this).find('[name^="Tarea."]').length > 0) {
        if (!validarFormularioActividad(this)) {
            e.preventDefault();
            return false;
        }
    }
});

$('<style>').text(`
    .btn-pulse {
        animation: pulse 0.2s ease-in-out;
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(0.95); }
        100% { transform: scale(1); }
    }

    .badge-hover {
        transform: scale(1.1);
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }

    .card {
        transition: all 0.3s ease;
    }

    .loading-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(26, 26, 46, 0.9);
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .loading-spinner {
        border: 4px solid rgba(102, 126, 234, 0.3);
        border-radius: 50%;
        border-top: 4px solid #667eea;
        width: 50px;
        height: 50px;
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
`).appendTo('head');
