﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using razordb.Models;
using razordb.Services;

namespace razordb.Pages
{
    public class CreateModel : PageModel
    {
        private readonly IActividadService _servicioActividades;

        public CreateModel(IActividadService servicioActividades)
        {
            _servicioActividades = servicioActividades;
        }

        [BindProperty]
        public Tarea Tarea { get; set; } = new Tarea();

        public IActionResult OnGet()
        {
            // Configurar valores predeterminados
            Tarea.fechaVencimiento = DateTime.Now.AddDays(1);
            Tarea.estado = "Pendiente";
            
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                TempData["MensajeError"] = "Por favor corrija los errores en el formulario";
                return Page();
            }

            try
            {
                // Crear la actividad usando el servicio
                var actividadCreada = await _servicioActividades.CrearActividadAsync(Tarea);
                
                TempData["MensajeExito"] = $"Actividad '{actividadCreada.nombreTarea}' creada exitosamente";
                
                return RedirectToPage("./Index");
            }
            catch (Exception ex)
            {
                TempData["MensajeError"] = "Error al crear la actividad. Intente nuevamente.";
                ModelState.AddModelError(string.Empty, "Ocurrió un error al guardar la actividad.");
                return Page();
            }
        }

        public async Task<IActionResult> OnPostValidarNombreAsync(string nombreTarea)
        {
            // Validación AJAX para verificar nombres duplicados (opcional)
            if (string.IsNullOrWhiteSpace(nombreTarea) || nombreTarea.Length < 3)
            {
                return new JsonResult(new { valido = false, mensaje = "El nombre debe tener al menos 3 caracteres" });
            }

            // Aquí podrías agregar validación para nombres duplicados si lo deseas
            var todasActividades = await _servicioActividades.ObtenerTodasLasActividadesAsync();
            var nombreExiste = todasActividades.Any(a => 
                a.nombreTarea.Equals(nombreTarea, StringComparison.OrdinalIgnoreCase));

            if (nombreExiste)
            {
                return new JsonResult(new { valido = false, mensaje = "Ya existe una actividad con este nombre" });
            }

            return new JsonResult(new { valido = true, mensaje = "Nombre disponible" });
        }
    }
}
