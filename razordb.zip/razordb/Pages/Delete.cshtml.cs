﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using razordb.Models;
using razordb.Services;

namespace razordb.Pages
{
    public class DeleteModel : PageModel
    {
        private readonly IActividadService _servicioActividades;

        public DeleteModel(IActividadService servicioActividades)
        {
            _servicioActividades = servicioActividades;
        }

        [BindProperty]
        public Tarea Tarea { get; set; } = new Tarea();

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var actividad = await _servicioActividades.ObtenerActividadPorIdAsync(id.Value);

            if (actividad == null)
            {
                return NotFound();
            }

            Tarea = actividad;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            try
            {
                var resultado = await _servicioActividades.EliminarActividadAsync(id.Value);
                
                if (resultado)
                {
                    TempData["MensajeExito"] = $"Actividad '{Tarea.nombreTarea}' eliminada correctamente";
                }
                else
                {
                    TempData["MensajeError"] = "La actividad no fue encontrada";
                    return NotFound();
                }
            }
            catch (Exception)
            {
                TempData["MensajeError"] = "Error al eliminar la actividad";
                return Page();
            }

            return RedirectToPage("./Index");
        }

        public async Task<IActionResult> OnPostMarcarComoCompletaAsync(int id)
        {
            try
            {
                var resultado = await _servicioActividades.CambiarEstadoActividadAsync(id, "Finalizado");
                
                if (resultado)
                {
                    TempData["MensajeExito"] = "Actividad marcada como completada en lugar de eliminada";
                    return RedirectToPage("./Index");
                }
                else
                {
                    TempData["MensajeError"] = "Error al cambiar el estado de la actividad";
                    return RedirectToPage(new { id });
                }
            }
            catch (Exception)
            {
                TempData["MensajeError"] = "Error al procesar la solicitud";
                return RedirectToPage(new { id });
            }
        }
    }
}
