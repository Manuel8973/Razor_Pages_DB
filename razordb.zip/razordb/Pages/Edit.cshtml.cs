﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using razordb.Models;
using razordb.Services;

namespace razordb.Pages
{
    public class EditModel : PageModel
    {
        private readonly IActividadService _servicioActividades;

        public EditModel(IActividadService servicioActividades)
        {
            _servicioActividades = servicioActividades;
        }

        [BindProperty]
        public Tarea Tarea { get; set; } = new Tarea();

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var actividad = await _servicioActividades.ObtenerActividadPorIdAsync(id.Value);
            if (actividad == null)
            {
                return NotFound();
            }

            Tarea = actividad;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                TempData["MensajeError"] = "Por favor corrija los errores en el formulario";
                return Page();
            }

            try
            {
                var resultado = await _servicioActividades.ActualizarActividadAsync(Tarea);
                
                if (resultado)
                {
                    TempData["MensajeExito"] = $"Actividad '{Tarea.nombreTarea}' actualizada correctamente";
                    return RedirectToPage("./Details", new { id = Tarea.Id });
                }
                else
                {
                    TempData["MensajeError"] = "La actividad no fue encontrada";
                    return NotFound();
                }
            }
            catch (Exception)
            {
                TempData["MensajeError"] = "Error al actualizar la actividad";
                ModelState.AddModelError(string.Empty, "Ocurrió un error al guardar los cambios.");
                return Page();
            }
        }

        public async Task<IActionResult> OnPostCambiarEstadoRapidoAsync(int id, string nuevoEstado)
        {
            var resultado = await _servicioActividades.CambiarEstadoActividadAsync(id, nuevoEstado);
            
            if (resultado)
            {
                TempData["MensajeExito"] = $"Estado cambiado a {nuevoEstado}";
            }
            else
            {
                TempData["MensajeError"] = "Error al cambiar el estado";
            }

            return RedirectToPage(new { id });
        }
    }
}
