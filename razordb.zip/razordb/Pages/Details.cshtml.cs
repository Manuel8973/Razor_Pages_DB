﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using razordb.Models;
using razordb.Services;

namespace razordb.Pages
{
    public class DetailsModel : PageModel
    {
        private readonly IActividadService _servicioActividades;

        public DetailsModel(IActividadService servicioActividades)
        {
            _servicioActividades = servicioActividades;
        }

        public Tarea Tarea { get; set; } = new Tarea();

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var actividad = await _servicioActividades.ObtenerActividadPorIdAsync(id.Value);
            if (actividad == null)
            {
                return NotFound();
            }

            Tarea = actividad;
            return Page();
        }
    }
}
