﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using razordb.Data;
using razordb.Models;
using razordb.Services;

namespace razordb.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IActividadService _servicioActividades;

        public IndexModel(IActividadService servicioActividades)
        {
            _servicioActividades = servicioActividades;
        }

        public IList<Tarea> Tarea { get; set; } = new List<Tarea>();
        public EstadisticasActividades Estadisticas { get; set; } = new EstadisticasActividades();

        public async Task OnGetAsync()
        {
            // Obtener todas las actividades
            var actividades = await _servicioActividades.ObtenerTodasLasActividadesAsync();
            Tarea = actividades.ToList();

            // Calcular estadísticas
            Estadisticas = _servicioActividades.ObtenerEstadisticas(actividades);
        }

        public async Task<IActionResult> OnPostCambiarEstadoAsync(int id, string nuevoEstado)
        {
            var resultado = await _servicioActividades.CambiarEstadoActividadAsync(id, nuevoEstado);
            
            if (resultado)
            {
                TempData["MensajeExito"] = "Estado actualizado correctamente";
            }
            else
            {
                TempData["MensajeError"] = "Error al actualizar el estado";
            }

            return RedirectToPage();
        }
    }
}
